import React from 'react';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="logo">ExploreMate</div>
      <div className="nav-links">
        <a href="#saved">Home</a>
        <a href="#partner">Partner With Us</a>
        <a href="#installment">Guides</a>
        <a href="#my-booking">My Booking</a>
        <a href="#login" className="login">Login</a>
        <a href="#signup" className="signup">Sign Up</a>
      </div>
    </nav>
  );
};

export default Navbar;