// src/components/OffersSection.js
import React from 'react';
import './OffersSection.css'; // Import the CSS file for styling

const OffersSection = () => {
    const offersData = [
        {
            title: "London",
            description: "London is the capital and largest city of both England and the United Kingdom.London is the capital and largest city of England and the United Kingdom",
            buttonText: "Book Now",
            image: "https://th.bing.com/th/id/R.3cca809024079d5a26741fe974026e70?rik=NPLshKmdsZYALA&riu=http%3a%2f%2fmedia.cntraveler.com%2fphotos%2f598339c9b7a86962e8e27c5d%2fmaster%2fpass%2fParis_GettyImages-601763009.jpg&ehk=1sSok1VLsf46Z7UigpsucOVYwAclWQL1zfyCy5qdbiw%3d&risl=&pid=ImgRaw&r=0" // Replace with actual image URL
        },
        {
            title: "Maldives",
            description: "The Maldive Islands are a series of coral atolls built up from the crowns of a submerged ancient volcanic mountain range. A detailed look at the cost of living in maldives",
            buttonText: "Book Now",
            image: "https://tourismteacher.com/wp-content/uploads/2020/09/pexels-photo-753626.jpeg" // Replace with actual image URL
        },
        {
            title: "Thailand",
            description: "Thailand, officially the Kingdom of Thailand and historically known as Siam (the official name until 1939), is a country in Southeast Asia on the Indochinese Peninsula.",
            buttonText: "Book Now",
            image: "https://media.gettyimages.com/id/984661764/photo/sunrise-with-grand-palace-of-bangkok-thailand.jpg?b=1&s=170667a&w=0&k=20&c=NVlyABDVBPeoexc4T-bJYK4_bHovWacIOH8mUfZNoOA=" // Replace with actual image URL
        },
        {
            title: "Korea",
            description: "South Korea, officially the Republic of Korea (ROK). It constitutes the southern half of the Korean Peninsula and borders North Korea along the Korean Demilitarized Zone",
            buttonText: "Book Now",
            image: "https://philstarlife.s3.ap-east-1.amazonaws.com/pslife_photos/Nick/South%20Korea.jpg" // Replace with actual image URL
        },
    ];

    return (
        <section className="offers-section">
            <div className="container mx-auto px-4 text-center">
                <h2 className="section-title">Guides for your next vacation</h2>
                
                <div className="offers-grid">
                    {offersData.map((offer, index) => (
                        <div key={index} className="offer-card">
                            <img src={offer.image} alt={offer.title} className="offer-image" />
                            <h3 className="offer-title">{offer.title}</h3>
                            <p className="offer-description">{offer.description}</p>
                            <button className="offer-button">{offer.buttonText}</button>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default OffersSection;
