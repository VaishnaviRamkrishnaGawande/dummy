import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import BookingSection from './components/BookingSection';
import GuideSection from './components/GuideSection';
import Footer from './components/Footer'; 
import './App.css';
import OffersSection from './components/OffersSection';

 

const App = () => {
  return (
    <div>
      <Navbar />
      <HeroSection />
      <OffersSection />
      <BookingSection />
      <GuideSection />
      <Footer />
    </div>
  );
};

export default App;